package com.greatlearning.student.service;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.greatlearning.student.entity.Student;

@Repository
public class BookServiceImpl implements BookService {

	private SessionFactory sessionFactory;

	// create session
	private Session session;

	@Autowired
	BookServiceImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
		try {
			session = sessionFactory.getCurrentSession();
		} catch (HibernateException e) {
			session = sessionFactory.openSession();
		}

	}

	@Transactional
	public List<Student> findAll() {
		
		Transaction tx = session.beginTransaction();

		// find all the records from the database table
		List<Student> books = session.createQuery("from Student").list();

		tx.commit();

		return books;
	}

	@Transactional
	public Student findById(int id) {

		Student book = new Student();

		
		Transaction tx = session.beginTransaction();

		// find record with Id from the database table
		book = session.get(Student.class, id);

		tx.commit();

		return book;
	}

	@Transactional
	public void save(Student theBook) {

		
		Transaction tx = session.beginTransaction();

		// save transaction
		session.saveOrUpdate(theBook);

		tx.commit();

	}

	@Transactional
	public void deleteById(int id) {

	
		Transaction tx = session.beginTransaction();

		// get transaction
		Student book = session.get(Student.class, id);

		// delete record
		session.delete(book);

		tx.commit();

	}

	@Transactional
	public List<Student> searchBy(String Name, String Department) {

		
		Transaction tx = session.beginTransaction();
		String query = "";
		if (Name.length() != 0 && Department.length() != 0)
			query = "from Student where name like '%" + Name + "%' or department like '%" + Department + "%'";
		else if (Name.length() != 0)
			query = "from Student where name like '%" + Name + "%'";
		else if (Department.length() != 0)
			query = "from Student where department like '%" + Department + "%'";
		else
			System.out.println("Cannot search without input data");

		List<Student> book = session.createQuery(query).list();

		tx.commit();

		return book;
	}

	// print the loop
	@Transactional
	public void print(List<Student> book) {

		for (Student b : book) {
			System.out.println(b);
		}
	}

}